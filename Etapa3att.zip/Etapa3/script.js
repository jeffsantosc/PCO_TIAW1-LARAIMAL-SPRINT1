export class formulariopostagem {
    constructor(idForm, idtextarea, idulposts) {
        this.form = document.getElementById(idForm)
        this.textarea = document.getElementById(idtextarea)
        this.Ulpost = document.getElementById(idulpost)
        this.addSubmit();
    }

    onSubmit() {
        this.form.addEventListener('submit', func)
    }

    addSubmit() {
        const handleSubmit = (event) => {
            event.preventDefault();

            const newPost = document.createElement('li')
            newPost.classList.add('post');
            newPost.innerHTML = `
           <div class="inforusuariopost">
           <div class="imguserpost"></div>
           <div class="nomehora">
               <strong>Nome</strong>
               <p>hora</p>
           </div>
       </div>
       <h4>A importância da Vacinação</h4>
       <p>
           ${this.textarea.value}
       </p>

       <div class="actionbtnposts">
           <button type="button" class="arquivopost"> <img src="" alt="Comentar">Comentar</button>
           <button type="button" class="arquivopost"> <img src="" alt="Compartilhar">Compartilhar</button>

       </div>

           `;
           this.ulpost.append(newPost);
           this.textarea.value = "";

        }

        this.onSubmit(handleSubmit)
    }


}
const formulariopostagem = new formulariopostagem('formulariopostagem', 'textarea', 'posts')
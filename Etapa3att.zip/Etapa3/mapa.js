const enderecoLojaCliente = "Endereço do Cliente";

const geocoder = new google.maps.Geocoder();

geocoder.geocode({ address: enderecoLojaCliente }, (results, status) => {
    if (status === "OK" && results[0]) {
        const coordenadas = results[0].geometry.location;
        const clienteLoja = {
            nome: "Loja do Cliente",
            descricao: "Descrição da Loja do Cliente",
            imagem: "imagem-loja-cliente.jpg",
            coordenadas: coordenadas,
            maisInformacoes: "link-para-loja-cliente.html",
        };

        const markerClienteLoja = new google.maps.Marker({
            position: clienteLoja.coordenadas,
            map: map, 
        });

        markerClienteLoja.addListener("click", () => {
            document.getElementById("placeImage").src = clienteLoja.imagem;
            document.getElementById("placeName").textContent = clienteLoja.nome;
            document.getElementById("placeDescription").textContent = clienteLoja.descricao;
            const moreInfoButton = document.getElementById("moreInfo");
            moreInfoButton.href = clienteLoja.maisInformacoes;
            moreInfoButton.style.display = "block";
        });
    } else {
        console.error("Falha na geocodificação do endereço.");
    }
});